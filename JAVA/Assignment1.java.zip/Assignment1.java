public class Assignment1 {

    public static void main(String[] args) {
        System.out.println("Rujani Mahmud");
        System.out.println("Java May 2021");
        System.out.println("I'm really sleepy");
        System.out.println("Omaha, Ne");
    }
    
}
